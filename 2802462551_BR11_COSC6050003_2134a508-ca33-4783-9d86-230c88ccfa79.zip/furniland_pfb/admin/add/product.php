<?php
require_once '../../config/db.php';
require '../../config/validator.php';


isLogin();
isAdmin();

$error = "";


$vendors = $conn->query("SELECT * FROM vendors");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productName = trim($_POST['productName']);
    $description = trim($_POST['description']);
    $price = $_POST['price'];
    $vendorID = $_POST['vendorID'];
    

    $imageName = $_FILES['image']['name'];
    $imageTmp = $_FILES['image']['tmp_name'];
    $imageError = $_FILES['image']['error'];


    if (strlen($productName) < 3 || strlen($productName) > 30) {
        $error = "Product Name must be between 3 and 30 characters.";
    } elseif (empty($description)) {
        $error = "Description must be filled.";
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = "Price must be a number greater than 0.";
    } elseif (empty($vendorID)) {
        $error = "Please select a vendor.";
    } elseif ($imageError === 4) {
        $error = "Please upload an image.";
    } else {

        $allowedExt = ['jpg', 'jpeg', 'png'];
        $fileExt = explode('.', $imageName);
        $fileActualExt = strtolower(end($fileExt));

        if (!in_array($fileActualExt, $allowedExt)) {
            $error = "Invalid file type! Only JPG and PNG allowed.";
        } else {
            $newImageName = uniqid('', true) . "." . $fileActualExt;
            $uploadDestination = '../../assets/uploads/' . $newImageName;

            if (move_uploaded_file($imageTmp, $uploadDestination)) {
                $stmt = $conn->prepare("INSERT INTO products (productName, description, price, image, vendorID) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("ssisi", $productName, $description, $price, $newImageName, $vendorID);

                if ($stmt->execute()) {
                    header("Location: ../manage_product.php");
                    exit;
                } else {
                    $error = "Database Error: " . $conn->error;
                }
            } else {
                $error = "Failed to upload image. Check folder permissions.";
            }
        }
    }
}

include '../../utils/header.php';
?>

<div class="auth-page">
    <div class="auth-card wide product-boxs">
        <h2 style="text-align: left;" class="auth-title">Add New Product</h2>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
                <label class="form-label">Product Name</label>
                <input type="text" name="productName" required placeholder="e.g. Modern Sofa">
            </div>

            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" rows="4" required placeholder="Product details..."></textarea>
            </div>

            <div class="form-row">
                <div class="form-col">
                    <label class="form-label">Price (IDR)</label>
                    <input type="number" name="price" min="1" required placeholder="100000">
                </div>

                <div class="form-col">
                    <label class="form-label">Vendor</label>
                    <select name="vendorID" required>
                        <option value="" disabled selected>Select Vendor</option>
                        <?php while($v = $vendors->fetch_assoc()): ?>
                            <option value="<?= $v['vendorID'] ?>"><?= htmlspecialchars($v['vendorName']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Product Image (.jpg, .png)</label>

                <input type="file" name="image" id="imageInput" accept=".jpg, .jpeg, .png" required class="file-input">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-full">Add Product</button>
            </div>

        </form>
    </div>
</div>

<?php include '../../utils/footer.php'; ?>