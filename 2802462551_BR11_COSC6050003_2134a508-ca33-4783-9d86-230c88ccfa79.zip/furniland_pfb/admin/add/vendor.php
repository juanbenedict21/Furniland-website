<?php
require_once '../../config/db.php';
require_once '../../config/validator.php';

isLogin();
isAdmin();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vendorName = trim($_POST['vendorName']);
    $location = trim($_POST['location']);

    if (empty($vendorName) || empty($location)) {
        $error = "All fields must be filled.";
    } elseif (strlen($vendorName) > 20) {
        $error = "Vendor Name maximum 20 characters.";
    } elseif (strlen($location) > 100) {
        $error = "Location maximum 100 characters.";
    } else {
        $stmt = $conn->prepare("INSERT INTO vendors (vendorName, location) VALUES (?, ?)");
        $stmt->bind_param("ss", $vendorName, $location);

        if ($stmt->execute()) {
            header("Location: ../manage_vendor.php");
            exit;
        } else {
            $error = "Database Error: " . $conn->error;
        }
    }
}

include '../../utils/header.php';
?>

<div class="auth-page">
    <div class="auth-card wide">
        <h3 class="auth-titles">Add Vendor</h3>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Vendor Name</label>
                <input type="text" name="vendorName" maxlength="20" required >
            </div>

            <div class="form-group">
                <label class="form-label">Location</label>
                <input type="text" name="location" maxlength="100" required >
            </div>

            <div class="form-actions">
                <button type="submit" class="btn">Add Vendor</button>
            </div>
        </form>
    </div>
</div>

<?php include '../../utils/footer.php'; ?>